package org.reliefwisdom.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
