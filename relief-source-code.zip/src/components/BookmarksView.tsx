import React, { useState } from 'react';
import { Bookmark, Search, Trash2 } from 'lucide-react';
import {
  AppLang,
  BookmarkItem,
  HydratedVerse,
  ReadingPreferences,
} from '../types';
import { UI_COPY } from '../i18n/translations';
import { VerseCard } from './VerseCard';

interface BookmarksViewProps {
  lang: AppLang;
  bookmarks: BookmarkItem[];
  preferences: ReadingPreferences;
  onToggleBookmark: (verse: HydratedVerse) => void;
  onUpdateNote: (id: string, note: string) => void;
}

export const BookmarksView: React.FC<BookmarksViewProps> = ({
  lang,
  bookmarks,
  preferences,
  onToggleBookmark,
  onUpdateNote,
}) => {
  const t = UI_COPY[lang];
  const [filter, setFilter] = useState<'all' | 'quran' | 'gita'>('all');
  const [query, setQuery] = useState('');
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [draftNote, setDraftNote] = useState('');

  const filtered = bookmarks.filter((item) => {
    if (filter !== 'all' && item.verse.scripture !== filter) return false;
    const q = query.trim().toLowerCase();
    if (!q) return true;
    return (
      item.verse.reference.toLowerCase().includes(q) ||
      item.verse.englishText.toLowerCase().includes(q) ||
      item.verse.hindiText.toLowerCase().includes(q) ||
      (item.note || '').toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-8 pb-10">
      <section className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-5 border-b border-[#F3F0E8]/8">
        <div>
          <h1 className="font-display text-3xl sm:text-4xl font-medium text-[#F3F0E8]">
            {t.bookmarks.title}
          </h1>
          <p className="text-sm text-[#A6A197] mt-1">{t.bookmarks.subtitle}</p>
        </div>

        <div className="inline-flex items-center p-1 bg-[#15181C] border border-[#F3F0E8]/10 rounded-xl self-start">
          {(['all', 'quran', 'gita'] as const).map((tab) => (
            <button
              key={tab}
              type="button"
              onClick={() => setFilter(tab)}
              className={`min-h-[40px] px-4 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                filter === tab
                  ? 'bg-[#C9A449] text-[#0D0E11]'
                  : 'text-[#A6A197] hover:text-[#F3F0E8]'
              }`}
            >
              {tab === 'all'
                ? t.bookmarks.filterAll
                : tab === 'quran'
                ? t.bookmarks.filterQuran
                : t.bookmarks.filterGita}
            </button>
          ))}
        </div>
      </section>

      {bookmarks.length > 0 && (
        <div className="relative">
          <Search className="w-4 h-4 text-[#7D7970] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t.bookmarks.searchPlaceholder}
            className="w-full min-h-[44px] bg-[#15181C] border border-[#F3F0E8]/10 rounded-xl pl-10 pr-4 py-2 text-sm text-[#F3F0E8] placeholder:text-[#7D7970] focus:outline-none focus:border-[#C9A449]"
          />
        </div>
      )}

      {filtered.length === 0 ? (
        <div className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-3xl p-10 text-center space-y-3">
          <Bookmark className="w-8 h-8 text-[#C9A449] mx-auto" />
          <h2 className="font-display text-2xl text-[#F3F0E8]">
            {t.bookmarks.emptyTitle}
          </h2>
          <p className="text-sm text-[#A6A197] max-w-md mx-auto leading-relaxed">
            {t.bookmarks.emptyDesc}
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {filtered.map((item) => {
            const isEditing = editingNoteId === item.verse.id;
            return (
              <div key={item.verse.id} className="space-y-2">
                <VerseCard
                  verse={item.verse}
                  lang={lang}
                  preferences={preferences}
                  isBookmarked
                  onToggleBookmark={onToggleBookmark}
                />

                <div className="bg-[#15181C] border border-[#F3F0E8]/8 rounded-2xl p-4 sm:p-5 flex flex-col gap-3">
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-xs uppercase tracking-widest text-[#A6A197]">
                      {t.bookmarks.personalNote}
                    </span>
                    <div className="flex items-center gap-2">
                      {!isEditing && (
                        <button
                          type="button"
                          onClick={() => {
                            setEditingNoteId(item.verse.id);
                            setDraftNote(item.note || '');
                          }}
                          className="min-h-[36px] px-3 text-xs font-medium text-[#C9A449] hover:underline cursor-pointer"
                        >
                          {item.note ? (lang === 'hi' ? 'संपादित करें' : 'Edit Note') : (lang === 'hi' ? '+ नोट जोड़ें' : '+ Add Note')}
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => onToggleBookmark(item.verse)}
                        className="min-h-[36px] px-2.5 text-xs text-[#A6A197] hover:text-[#F3F0E8] inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>{t.bookmarks.remove}</span>
                      </button>
                    </div>
                  </div>

                  {isEditing ? (
                    <div className="space-y-2.5">
                      <textarea
                        rows={2}
                        value={draftNote}
                        onChange={(e) => setDraftNote(e.target.value)}
                        className="w-full bg-[#0D0E11] border border-[#F3F0E8]/12 rounded-xl px-3.5 py-2 text-sm text-[#F3F0E8] focus:outline-none focus:border-[#C9A449]"
                      />
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            onUpdateNote(item.verse.id, draftNote);
                            setEditingNoteId(null);
                          }}
                          className="min-h-[40px] px-4 py-1.5 rounded-xl bg-[#C9A449] text-[#0D0E11] text-xs font-semibold cursor-pointer"
                        >
                          {t.bookmarks.saveNote}
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingNoteId(null)}
                          className="min-h-[40px] px-4 py-1.5 rounded-xl border border-[#F3F0E8]/15 text-xs text-[#A6A197] cursor-pointer"
                        >
                          {t.common.close}
                        </button>
                      </div>
                    </div>
                  ) : item.note ? (
                    <p className="text-sm text-[#F3F0E8]/90 leading-relaxed">
                      {item.note}
                    </p>
                  ) : null}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
