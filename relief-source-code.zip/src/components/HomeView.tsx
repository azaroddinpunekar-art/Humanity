import React, { useState } from 'react';
import {
  ArrowRight,
  BookOpen,
  Compass,
  MessageSquareHeart,
  Scale,
  Send,
} from 'lucide-react';
import {
  AppLang,
  DailyWisdom,
  HydratedVerse,
  NavTab,
  ReadingPreferences,
  SituationCategory,
} from '../types';
import { UI_COPY } from '../i18n/translations';
import { VerseCard } from './VerseCard';

interface HomeViewProps {
  lang: AppLang;
  dailyWisdom: DailyWisdom | null;
  situations: SituationCategory[];
  loading: boolean;
  preferences: ReadingPreferences;
  isBookmarked: (id: string) => boolean;
  onToggleBookmark: (verse: HydratedVerse) => void;
  onNavigate: (tab: NavTab) => void;
  onOpenScripture: (scripture: 'quran' | 'gita') => void;
  onOpenOneHumanityTopic: (topicId: string) => void;
  onAskQuestion: (question: string) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  lang,
  dailyWisdom,
  situations,
  loading,
  preferences,
  isBookmarked,
  onToggleBookmark,
  onNavigate,
  onOpenScripture,
  onOpenOneHumanityTopic,
  onAskQuestion,
}) => {
  const t = UI_COPY[lang];
  const [selectedSituationId, setSelectedSituationId] = useState<string>('relationships');
  const [customSituation, setCustomSituation] = useState('');
  const [heroImgFailed, setHeroImgFailed] = useState(false);

  const activeSituation =
    situations.find((s) => s.id === selectedSituationId) || situations[0] || null;

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = customSituation.trim();
    if (!trimmed) return;
    onAskQuestion(trimmed);
  };

  return (
    <div className="space-y-14 pb-10">
      {/* Hero Split */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch pt-2">
        <div className="lg:col-span-7 flex flex-col justify-between bg-[#15181C] border border-[#F3F0E8]/10 rounded-3xl p-6 sm:p-8 lg:p-10">
          <div className="space-y-5">
            <p className="text-xs tracking-widest uppercase text-[#C9A449]">
              {t.home.heroEyebrow}
            </p>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-[54px] font-medium text-[#F3F0E8] leading-[1.08] text-balance">
              {t.home.heroTitle}
            </h1>
            <p className="text-base text-[#A6A197] leading-relaxed max-w-2xl">
              {t.home.heroDesc}
            </p>
          </div>

          <div className="pt-8 mt-8 border-t border-[#F3F0E8]/8 flex flex-wrap items-center gap-5">
            <button
              type="button"
              onClick={() => onNavigate('ask-relief')}
              className="min-h-[48px] px-6 py-3 rounded-xl bg-[#C9A449] text-[#0D0E11] text-sm font-semibold inline-flex items-center gap-2 hover:bg-[#D8B55B] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>{t.home.primaryCta}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => onNavigate('one-humanity')}
              className="min-h-[44px] px-2 text-sm font-medium text-[#F3F0E8] hover:text-[#C9A449] transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>{t.home.secondaryCta}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="lg:col-span-5 relative min-h-[260px] lg:min-h-[380px] rounded-3xl overflow-hidden border border-[#F3F0E8]/10 bg-[#15181C]">
          {!heroImgFailed ? (
            <img
              src="/src/assets/images/hero_sanctuary_horizon_1795635213996.jpg"
              alt="Quiet stone colonnade illuminated by warm dawn light reflecting on still water"
              referrerPolicy="no-referrer"
              onError={() => setHeroImgFailed(true)}
              className="w-full h-full object-cover lg:absolute lg:inset-0"
            />
          ) : (
            <div className="w-full h-full min-h-[260px] bg-gradient-to-br from-[#1C1F26] via-[#15181C] to-[#0D0E11] flex flex-col items-center justify-center p-8 text-center">
              <Compass className="w-10 h-10 text-[#C9A449] mb-3" />
              <p className="font-display text-2xl text-[#F3F0E8]">{t.brand}</p>
              <p className="text-xs text-[#A6A197] mt-1">{t.tagline}</p>
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-[#0D0E11]/85 via-[#0D0E11]/20 to-transparent pointer-events-none" />
          <div className="absolute bottom-5 left-5 right-5 flex items-center justify-between text-xs text-[#F3F0E8]/85">
            <span>{t.common.quran}</span>
            <span aria-hidden="true">·</span>
            <span>{t.common.gita}</span>
          </div>
        </div>
      </section>

      {/* Four Exploration Doors */}
      <section className="space-y-5">
        <h2 className="font-display text-2xl md:text-3xl font-medium text-[#F3F0E8]">
          {t.home.doorsTitle}
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <button
            type="button"
            onClick={() => onOpenScripture('quran')}
            className="text-left bg-[#15181C] border border-[#F3F0E8]/10 hover:border-[#C9A449]/45 rounded-2xl p-5 transition-colors flex flex-col justify-between gap-4 min-h-[140px] cursor-pointer"
          >
            <BookOpen className="w-5 h-5 text-[#C9A449]" />
            <div>
              <h3 className="text-base font-semibold text-[#F3F0E8]">
                {t.home.doorQuranTitle}
              </h3>
              <p className="text-xs text-[#A6A197] mt-1 leading-relaxed">
                {t.home.doorQuranDesc}
              </p>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onOpenScripture('gita')}
            className="text-left bg-[#15181C] border border-[#F3F0E8]/10 hover:border-[#C9A449]/45 rounded-2xl p-5 transition-colors flex flex-col justify-between gap-4 min-h-[140px] cursor-pointer"
          >
            <BookOpen className="w-5 h-5 text-[#C9A449]" />
            <div>
              <h3 className="text-base font-semibold text-[#F3F0E8]">
                {t.home.doorGitaTitle}
              </h3>
              <p className="text-xs text-[#A6A197] mt-1 leading-relaxed">
                {t.home.doorGitaDesc}
              </p>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('one-humanity')}
            className="text-left bg-[#15181C] border border-[#F3F0E8]/10 hover:border-[#C9A449]/45 rounded-2xl p-5 transition-colors flex flex-col justify-between gap-4 min-h-[140px] cursor-pointer"
          >
            <Scale className="w-5 h-5 text-[#C9A449]" />
            <div>
              <h3 className="text-base font-semibold text-[#F3F0E8]">
                {t.home.doorHumanityTitle}
              </h3>
              <p className="text-xs text-[#A6A197] mt-1 leading-relaxed">
                {t.home.doorHumanityDesc}
              </p>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('ask-relief')}
            className="text-left bg-[#15181C] border border-[#F3F0E8]/10 hover:border-[#C9A449]/45 rounded-2xl p-5 transition-colors flex flex-col justify-between gap-4 min-h-[140px] cursor-pointer"
          >
            <MessageSquareHeart className="w-5 h-5 text-[#C9A449]" />
            <div>
              <h3 className="text-base font-semibold text-[#F3F0E8]">
                {t.home.doorAskTitle}
              </h3>
              <p className="text-xs text-[#A6A197] mt-1 leading-relaxed">
                {t.home.doorAskDesc}
              </p>
            </div>
          </button>
        </div>
      </section>

      {/* Daily Wisdom */}
      <section className="space-y-6">
        <div className="flex flex-wrap items-end justify-between gap-4 pb-3 border-b border-[#F3F0E8]/8">
          <div>
            <p className="text-xs uppercase tracking-widest text-[#C9A449]">
              {t.home.dailyWisdomTitle}
            </p>
            <h2 className="font-display text-2xl md:text-3xl font-medium text-[#F3F0E8] mt-1">
              {dailyWisdom ? dailyWisdom.title[lang] : t.home.dailyWisdomSubtitle}
            </h2>
          </div>

          {dailyWisdom && (
            <button
              type="button"
              onClick={() => onOpenOneHumanityTopic(dailyWisdom.topicId)}
              className="min-h-[44px] px-4 py-2 rounded-xl border border-[#F3F0E8]/15 text-xs font-medium text-[#F3F0E8] hover:border-[#C9A449] hover:text-[#C9A449] transition-colors inline-flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>{t.home.exploreCompare}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {loading && !dailyWisdom ? (
          <div className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-8 text-sm text-[#A6A197]">
            {t.common.loading}
          </div>
        ) : dailyWisdom ? (
          <div className="space-y-5">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              {dailyWisdom.quranVerse && (
                <VerseCard
                  verse={dailyWisdom.quranVerse}
                  lang={lang}
                  preferences={preferences}
                  isBookmarked={isBookmarked(dailyWisdom.quranVerse.id)}
                  onToggleBookmark={onToggleBookmark}
                  compact
                />
              )}
              {dailyWisdom.gitaVerse && (
                <VerseCard
                  verse={dailyWisdom.gitaVerse}
                  lang={lang}
                  preferences={preferences}
                  isBookmarked={isBookmarked(dailyWisdom.gitaVerse.id)}
                  onToggleBookmark={onToggleBookmark}
                  compact
                />
              )}
            </div>

            <div className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-5 md:p-6">
              <p className="text-xs uppercase tracking-widest text-[#C9A449] mb-2">
                {t.oneHumanity.sharedPrinciple}
              </p>
              <p className="text-sm md:text-base text-[#F3F0E8]/90 leading-relaxed">
                {dailyWisdom.sharedPrinciple[lang]}
              </p>
            </div>
          </div>
        ) : null}
      </section>

      {/* Situation Explorer */}
      <section className="space-y-6">
        <div className="space-y-2">
          <p className="text-xs uppercase tracking-widest text-[#C9A449]">
            {t.home.situationTitle}
          </p>
          <p className="text-sm md:text-base text-[#A6A197] max-w-3xl">
            {t.home.situationSubtitle}
          </p>
        </div>

        {/* Custom situation input without selecting a category */}
        <form
          onSubmit={handleCustomSubmit}
          className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row gap-3 items-stretch sm:items-center"
        >
          <div className="flex-1">
            <label htmlFor="custom-situation" className="sr-only">
              {t.home.customSituationLabel}
            </label>
            <input
              id="custom-situation"
              type="text"
              value={customSituation}
              onChange={(e) => setCustomSituation(e.target.value)}
              placeholder={t.home.customSituationPlaceholder}
              className="w-full min-h-[44px] bg-[#0D0E11] border border-[#F3F0E8]/12 rounded-xl px-4 py-2.5 text-sm text-[#F3F0E8] placeholder:text-[#7D7970] focus:outline-none focus:border-[#C9A449]"
            />
          </div>
          <button
            type="submit"
            disabled={!customSituation.trim()}
            className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#C9A449] text-[#0D0E11] text-sm font-semibold inline-flex items-center justify-center gap-2 hover:bg-[#D8B55B] disabled:opacity-40 disabled:cursor-not-allowed transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>{t.home.customSituationBtn}</span>
          </button>
        </form>

        {/* 11 Category Tabs */}
        <div className="flex flex-wrap gap-2">
          {situations.map((cat) => {
            const active = activeSituation?.id === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedSituationId(cat.id)}
                className={`min-h-[44px] px-4 py-2 rounded-xl text-xs sm:text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  active
                    ? 'bg-[#C9A449] text-[#0D0E11]'
                    : 'bg-[#15181C] text-[#A6A197] border border-[#F3F0E8]/10 hover:text-[#F3F0E8] hover:border-[#F3F0E8]/25'
                }`}
              >
                {cat.title[lang]}
              </button>
            );
          })}
        </div>

        {/* Active Situation Detail */}
        {activeSituation && (
          <div className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-3xl p-5 sm:p-7 space-y-6">
            <div className="flex flex-wrap items-start justify-between gap-4 pb-5 border-b border-[#F3F0E8]/8">
              <div>
                <h3 className="font-display text-2xl md:text-3xl font-medium text-[#F3F0E8]">
                  {activeSituation.title[lang]}
                </h3>
                <p className="text-sm text-[#A6A197] mt-1">
                  {activeSituation.summary[lang]}
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  onAskQuestion(
                    lang === 'hi'
                      ? `${activeSituation.title.hi} की परिस्थिति में मुझे क्या दृष्टिकोण और कदम अपनाने चाहिए?`
                      : `How can I navigate ${activeSituation.title.en.toLowerCase()} with clarity and wisdom?`
                  )
                }
                className="min-h-[44px] px-4 py-2 rounded-xl border border-[#C9A449]/40 text-xs font-medium text-[#C9A449] hover:bg-[#C9A449]/10 transition-colors inline-flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span>{t.home.askAboutSituation}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              <div className="space-y-4">
                <h4 className="text-xs uppercase tracking-widest text-[#C9A449]">
                  {t.common.quran}
                </h4>
                {activeSituation.quranVerses.map((v) => (
                  <VerseCard
                    key={v.id}
                    verse={v}
                    lang={lang}
                    preferences={preferences}
                    isBookmarked={isBookmarked(v.id)}
                    onToggleBookmark={onToggleBookmark}
                    compact
                  />
                ))}
              </div>

              <div className="space-y-4">
                <h4 className="text-xs uppercase tracking-widest text-[#C9A449]">
                  {t.common.gita}
                </h4>
                {activeSituation.gitaVerses.map((v) => (
                  <VerseCard
                    key={v.id}
                    verse={v}
                    lang={lang}
                    preferences={preferences}
                    isBookmarked={isBookmarked(v.id)}
                    onToggleBookmark={onToggleBookmark}
                    compact
                  />
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-4 border-t border-[#F3F0E8]/8">
              <div>
                <h4 className="text-xs uppercase tracking-widest text-[#A6A197] mb-2">
                  {t.oneHumanity.sharedPrinciple}
                </h4>
                <p className="text-sm md:text-base text-[#F3F0E8]/90 leading-relaxed">
                  {activeSituation.reflection[lang]}
                </p>
              </div>
              <div>
                <h4 className="text-xs uppercase tracking-widest text-[#A6A197] mb-2">
                  {t.home.practicalStepsLabel}
                </h4>
                <ul className="space-y-2">
                  {activeSituation.practicalSteps[lang].map((step, idx) => (
                    <li
                      key={idx}
                      className="text-sm text-[#F3F0E8]/90 leading-relaxed flex items-start gap-2.5"
                    >
                      <span className="font-mono-num text-xs text-[#C9A449] mt-1">
                        0{idx + 1}.
                      </span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}
      </section>
    </div>
  );
};
