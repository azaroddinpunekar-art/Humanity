import React, { useEffect, useState } from 'react';
import { ArrowLeft, ChevronLeft, ChevronRight, Search, X } from 'lucide-react';
import {
  AppLang,
  GitaChapterDetail,
  GitaChapterSummary,
  HydratedVerse,
  QuranSurahDetail,
  QuranSurahSummary,
  ReadingPreferences,
} from '../types';
import { UI_COPY } from '../i18n/translations';
import { VerseCard } from './VerseCard';

interface ScripturesViewProps {
  lang: AppLang;
  activeScripture: 'quran' | 'gita';
  onChangeScripture: (s: 'quran' | 'gita') => void;
  preferences: ReadingPreferences;
  onUpdatePreferences: (prefs: ReadingPreferences) => void;
  isBookmarked: (id: string) => boolean;
  onToggleBookmark: (verse: HydratedVerse) => void;
}

export const ScripturesView: React.FC<ScripturesViewProps> = ({
  lang,
  activeScripture,
  onChangeScripture,
  preferences,
  onUpdatePreferences,
  isBookmarked,
  onToggleBookmark,
}) => {
  const t = UI_COPY[lang];
  const [surahs, setSurahs] = useState<QuranSurahSummary[]>([]);
  const [chapters, setChapters] = useState<GitaChapterSummary[]>([]);
  const [selectedSurah, setSelectedSurah] = useState<QuranSurahDetail | null>(null);
  const [selectedChapter, setSelectedChapter] = useState<GitaChapterDetail | null>(null);
  const [chapterFilter, setChapterFilter] = useState('');
  const [loadingIndex, setLoadingIndex] = useState(true);
  const [loadingReader, setLoadingReader] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Global search across both scriptures
  const [searchQuery, setSearchQuery] = useState('');
  const [searchScope, setSearchScope] = useState<'all' | 'quran' | 'gita'>('all');
  const [searching, setSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<{
    quran: HydratedVerse[];
    gita: HydratedVerse[];
  } | null>(null);

  useEffect(() => {
    let mounted = true;
    setLoadingIndex(true);
    Promise.all([
      fetch('/api/quran/surahs').then((r) => r.json()),
      fetch('/api/gita/chapters').then((r) => r.json()),
    ])
      .then(([qData, gData]) => {
        if (!mounted) return;
        setSurahs(qData.surahs || []);
        setChapters(gData.chapters || []);
        setErrorMsg(null);
      })
      .catch(() => {
        if (!mounted) return;
        setErrorMsg(t.common.offlineNotice);
      })
      .finally(() => {
        if (mounted) setLoadingIndex(false);
      });
    return () => {
      mounted = false;
    };
  }, [t.common.offlineNotice]);

  const openSurah = async (surahNumber: number) => {
    setLoadingReader(true);
    setErrorMsg(null);
    setSearchResults(null);
    try {
      const res = await fetch(`/api/quran/surah/${surahNumber}`);
      if (!res.ok) throw new Error('Failed to load Surah');
      const data = (await res.json()) as QuranSurahDetail;
      setSelectedSurah(data);
      setSelectedChapter(null);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch {
      setErrorMsg(t.common.offlineNotice);
    } finally {
      setLoadingReader(false);
    }
  };

  const openGitaChapter = async (chapterNumber: number) => {
    setLoadingReader(true);
    setErrorMsg(null);
    setSearchResults(null);
    try {
      const res = await fetch(`/api/gita/chapter/${chapterNumber}`);
      if (!res.ok) throw new Error('Failed to load Chapter');
      const data = (await res.json()) as GitaChapterDetail;
      setSelectedChapter(data);
      setSelectedSurah(null);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch {
      setErrorMsg(t.common.offlineNotice);
    } finally {
      setLoadingReader(false);
    }
  };

  const handleGlobalSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    const q = searchQuery.trim();
    if (!q) return;
    setSearching(true);
    setErrorMsg(null);
    try {
      const res = await fetch(
        `/api/search?q=${encodeURIComponent(q)}&scripture=${searchScope}`
      );
      if (!res.ok) throw new Error('Search failed');
      const data = (await res.json()) as {
        quran: HydratedVerse[];
        gita: HydratedVerse[];
      };
      setSearchResults(data);
      setSelectedSurah(null);
      setSelectedChapter(null);
    } catch {
      setErrorMsg(t.common.offlineNotice);
    } finally {
      setSearching(false);
    }
  };

  const filteredSurahs = surahs.filter((s) => {
    const q = chapterFilter.trim().toLowerCase();
    if (!q) return true;
    return (
      String(s.number) === q ||
      s.englishName.toLowerCase().includes(q) ||
      s.englishNameTranslation.toLowerCase().includes(q) ||
      s.nameArabic.includes(q)
    );
  });

  const filteredChapters = chapters.filter((c) => {
    const q = chapterFilter.trim().toLowerCase();
    if (!q) return true;
    return (
      String(c.number) === q ||
      c.englishName.toLowerCase().includes(q) ||
      c.hindiName.includes(q) ||
      c.transliteration.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-8 pb-10">
      {/* Header & Search */}
      <section className="space-y-5">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl md:text-4xl font-medium text-[#F3F0E8]">
              {t.scriptures.title}
            </h1>
            <p className="text-sm text-[#A6A197] mt-1">{t.scriptures.subtitle}</p>
          </div>

          <div className="inline-flex items-center p-1 bg-[#15181C] border border-[#F3F0E8]/10 rounded-xl self-start">
            <button
              type="button"
              onClick={() => {
                onChangeScripture('quran');
                setSelectedChapter(null);
                setSelectedSurah(null);
                setSearchResults(null);
              }}
              className={`min-h-[40px] px-4 py-2 rounded-lg text-xs sm:text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeScripture === 'quran' && !selectedChapter
                  ? 'bg-[#C9A449] text-[#0D0E11]'
                  : 'text-[#A6A197] hover:text-[#F3F0E8]'
              }`}
            >
              {t.common.quran}
            </button>
            <button
              type="button"
              onClick={() => {
                onChangeScripture('gita');
                setSelectedSurah(null);
                setSelectedChapter(null);
                setSearchResults(null);
              }}
              className={`min-h-[40px] px-4 py-2 rounded-lg text-xs sm:text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeScripture === 'gita' && !selectedSurah
                  ? 'bg-[#C9A449] text-[#0D0E11]'
                  : 'text-[#A6A197] hover:text-[#F3F0E8]'
              }`}
            >
              {t.common.gita}
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <form
          onSubmit={handleGlobalSearch}
          className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-3 sm:p-4 flex flex-col lg:flex-row gap-3"
        >
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-[#7D7970] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.common.searchPlaceholder}
              className="w-full min-h-[44px] bg-[#0D0E11] border border-[#F3F0E8]/10 rounded-xl pl-10 pr-10 py-2 text-sm text-[#F3F0E8] placeholder:text-[#7D7970] focus:outline-none focus:border-[#C9A449]"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setSearchResults(null);
                }}
                aria-label={t.common.clear}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-[#A6A197] hover:text-[#F3F0E8] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center bg-[#0D0E11] border border-[#F3F0E8]/10 rounded-xl p-1">
              {(['all', 'quran', 'gita'] as const).map((scope) => (
                <button
                  key={scope}
                  type="button"
                  onClick={() => setSearchScope(scope)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    searchScope === scope
                      ? 'bg-[#1E2228] text-[#C9A449]'
                      : 'text-[#A6A197] hover:text-[#F3F0E8]'
                  }`}
                >
                  {scope === 'all'
                    ? t.bookmarks.filterAll
                    : scope === 'quran'
                    ? t.common.quranShort
                    : t.common.gitaShort}
                </button>
              ))}
            </div>

            <button
              type="submit"
              disabled={!searchQuery.trim() || searching}
              className="min-h-[44px] px-5 py-2 rounded-xl bg-[#C9A449] text-[#0D0E11] text-sm font-semibold hover:bg-[#D8B55B] disabled:opacity-40 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {searching ? '...' : t.scriptures.searchBtn}
            </button>
          </div>
        </form>

        {/* Display Script Controls */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <button
            type="button"
            onClick={() =>
              onUpdatePreferences({
                ...preferences,
                showOriginalScript: !preferences.showOriginalScript,
              })
            }
            className={`min-h-[40px] px-3.5 py-1.5 rounded-xl border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              preferences.showOriginalScript
                ? 'bg-[#C9A449]/15 border-[#C9A449]/40 text-[#E5C675]'
                : 'bg-[#15181C] border-[#F3F0E8]/10 text-[#A6A197]'
            }`}
          >
            {t.scriptures.showOriginal}
          </button>

          <button
            type="button"
            onClick={() =>
              onUpdatePreferences({
                ...preferences,
                showTransliteration: !preferences.showTransliteration,
              })
            }
            className={`min-h-[40px] px-3.5 py-1.5 rounded-xl border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              preferences.showTransliteration
                ? 'bg-[#C9A449]/15 border-[#C9A449]/40 text-[#E5C675]'
                : 'bg-[#15181C] border-[#F3F0E8]/10 text-[#A6A197]'
            }`}
          >
            {t.scriptures.showTranslit}
          </button>

          <button
            type="button"
            onClick={() =>
              onUpdatePreferences({
                ...preferences,
                showDualTranslation: !preferences.showDualTranslation,
              })
            }
            className={`min-h-[40px] px-3.5 py-1.5 rounded-xl border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              preferences.showDualTranslation
                ? 'bg-[#C9A449]/15 border-[#C9A449]/40 text-[#E5C675]'
                : 'bg-[#15181C] border-[#F3F0E8]/10 text-[#A6A197]'
            }`}
          >
            {t.scriptures.showDual}
          </button>
        </div>
      </section>

      {errorMsg && (
        <div className="bg-[#15181C] border border-[#C9A449]/35 rounded-2xl p-4 text-sm text-[#E5C675]">
          {errorMsg}
        </div>
      )}

      {/* Search Results View */}
      {searchResults && (
        <section className="space-y-6">
          <div className="flex items-center justify-between border-b border-[#F3F0E8]/8 pb-3">
            <h2 className="font-display text-2xl text-[#F3F0E8]">
              {t.scriptures.searchResultsTitle}: "{searchQuery}"
            </h2>
            <button
              type="button"
              onClick={() => setSearchResults(null)}
              className="min-h-[40px] px-3 text-xs font-medium text-[#C9A449] hover:underline cursor-pointer"
            >
              {t.scriptures.browseChapters}
            </button>
          </div>

          {searchResults.quran.length === 0 && searchResults.gita.length === 0 ? (
            <div className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-8 text-center text-sm text-[#A6A197]">
              {t.scriptures.noResults}
            </div>
          ) : (
            <div className="space-y-8">
              {searchResults.quran.length > 0 && (
                <div className="space-y-4">
                  <h3 className="text-xs uppercase tracking-widest text-[#C9A449]">
                    {t.common.quran} · {searchResults.quran.length}
                  </h3>
                  <div className="grid grid-cols-1 gap-4">
                    {searchResults.quran.map((v) => (
                      <VerseCard
                        key={v.id}
                        verse={v}
                        lang={lang}
                        preferences={preferences}
                        isBookmarked={isBookmarked(v.id)}
                        onToggleBookmark={onToggleBookmark}
                      />
                    ))}
                  </div>
                </div>
              )}

              {searchResults.gita.length > 0 && (
                <div className="space-y-4">
                  <h3 className="text-xs uppercase tracking-widest text-[#C9A449]">
                    {t.common.gita} · {searchResults.gita.length}
                  </h3>
                  <div className="grid grid-cols-1 gap-4">
                    {searchResults.gita.map((v) => (
                      <VerseCard
                        key={v.id}
                        verse={v}
                        lang={lang}
                        preferences={preferences}
                        isBookmarked={isBookmarked(v.id)}
                        onToggleBookmark={onToggleBookmark}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </section>
      )}

      {/* Surah Reader */}
      {!searchResults && selectedSurah && (
        <section className="space-y-6">
          <div className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-3xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-2">
              <button
                type="button"
                onClick={() => setSelectedSurah(null)}
                className="min-h-[40px] inline-flex items-center gap-1.5 text-xs font-medium text-[#C9A449] hover:underline cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>{t.scriptures.browseChapters}</span>
              </button>
              <div className="flex flex-wrap items-baseline gap-4">
                <h2 className="font-display text-3xl text-[#F3F0E8]">
                  {t.common.surah} {selectedSurah.number}: {selectedSurah.englishName}
                </h2>
                <span className="font-arabic text-2xl text-[#C9A449]" lang="ar">
                  {selectedSurah.nameArabic}
                </span>
              </div>
              <p className="text-xs text-[#A6A197]">
                {selectedSurah.englishNameTranslation} · {selectedSurah.revelationType} ·{' '}
                <span className="font-mono-num">
                  {selectedSurah.ayahs.length} {t.common.ayahsCount}
                </span>
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                disabled={selectedSurah.number <= 1}
                onClick={() => openSurah(selectedSurah.number - 1)}
                className="min-h-[44px] px-4 py-2 rounded-xl border border-[#F3F0E8]/12 text-xs font-medium text-[#F3F0E8] hover:border-[#C9A449] disabled:opacity-35 inline-flex items-center gap-1 cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>{t.scriptures.prevChapter}</span>
              </button>
              <button
                type="button"
                disabled={selectedSurah.number >= 114}
                onClick={() => openSurah(selectedSurah.number + 1)}
                className="min-h-[44px] px-4 py-2 rounded-xl border border-[#F3F0E8]/12 text-xs font-medium text-[#F3F0E8] hover:border-[#C9A449] disabled:opacity-35 inline-flex items-center gap-1 cursor-pointer"
              >
                <span>{t.scriptures.nextChapter}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {loadingReader ? (
            <div className="p-8 text-sm text-[#A6A197]">{t.common.loading}</div>
          ) : (
            <div className="space-y-4">
              {selectedSurah.ayahs.map((ayah) => {
                const hv: HydratedVerse = {
                  id: `quran:${selectedSurah.number}:${ayah.numberInSurah}`,
                  scripture: 'quran',
                  chapterNumber: selectedSurah.number,
                  verseNumber: ayah.numberInSurah,
                  chapterTitleEn: `${selectedSurah.englishName} (${selectedSurah.englishNameTranslation})`,
                  chapterTitleHi: `${selectedSurah.englishName} (${selectedSurah.number})`,
                  chapterTitleOriginal: selectedSurah.nameArabic,
                  reference: `Quran ${selectedSurah.number}:${ayah.numberInSurah}`,
                  originalText: ayah.arabic,
                  englishText: ayah.english,
                  hindiText: ayah.hindi,
                  attributionOriginal: selectedSurah.attribution.arabic,
                  attributionEn: selectedSurah.attribution.english,
                  attributionHi: selectedSurah.attribution.hindi,
                };
                return (
                  <VerseCard
                    key={hv.id}
                    verse={hv}
                    lang={lang}
                    preferences={preferences}
                    isBookmarked={isBookmarked(hv.id)}
                    onToggleBookmark={onToggleBookmark}
                  />
                );
              })}
            </div>
          )}
        </section>
      )}

      {/* Gita Chapter Reader */}
      {!searchResults && selectedChapter && (
        <section className="space-y-6">
          <div className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-3xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-2">
                <button
                  type="button"
                  onClick={() => setSelectedChapter(null)}
                  className="min-h-[40px] inline-flex items-center gap-1.5 text-xs font-medium text-[#C9A449] hover:underline cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>{t.scriptures.browseChapters}</span>
                </button>
                <div className="flex flex-wrap items-baseline gap-3">
                  <h2 className="font-display text-3xl text-[#F3F0E8]">
                    {t.common.chapter} {selectedChapter.number}:{' '}
                    {lang === 'hi'
                      ? selectedChapter.hindiName
                      : selectedChapter.englishName}
                  </h2>
                  <span className="font-devanagari text-lg text-[#C9A449]">
                    {selectedChapter.nameSanskrit}
                  </span>
                </div>
                <p className="text-xs text-[#A6A197]">
                  {selectedChapter.transliteration} ·{' '}
                  <span className="font-mono-num">
                    {selectedChapter.verses.length} {t.common.versesCount}
                  </span>
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  disabled={selectedChapter.number <= 1}
                  onClick={() => openGitaChapter(selectedChapter.number - 1)}
                  className="min-h-[44px] px-4 py-2 rounded-xl border border-[#F3F0E8]/12 text-xs font-medium text-[#F3F0E8] hover:border-[#C9A449] disabled:opacity-35 inline-flex items-center gap-1 cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>{t.scriptures.prevChapter}</span>
                </button>
                <button
                  type="button"
                  disabled={selectedChapter.number >= 18}
                  onClick={() => openGitaChapter(selectedChapter.number + 1)}
                  className="min-h-[44px] px-4 py-2 rounded-xl border border-[#F3F0E8]/12 text-xs font-medium text-[#F3F0E8] hover:border-[#C9A449] disabled:opacity-35 inline-flex items-center gap-1 cursor-pointer"
                >
                  <span>{t.scriptures.nextChapter}</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {(selectedChapter.summaryEn || selectedChapter.summaryHi) && (
              <p className="text-sm text-[#A6A197] leading-relaxed pt-4 border-t border-[#F3F0E8]/8">
                {lang === 'hi' ? selectedChapter.summaryHi : selectedChapter.summaryEn}
              </p>
            )}
          </div>

          {loadingReader ? (
            <div className="p-8 text-sm text-[#A6A197]">{t.common.loading}</div>
          ) : (
            <div className="space-y-4">
              {selectedChapter.verses.map((v) => {
                const hv: HydratedVerse = {
                  id: `gita:${selectedChapter.number}:${v.verse}`,
                  scripture: 'gita',
                  chapterNumber: selectedChapter.number,
                  verseNumber: v.verse,
                  chapterTitleEn: `Chapter ${selectedChapter.number}: ${selectedChapter.englishName}`,
                  chapterTitleHi: `अध्याय ${selectedChapter.number}: ${selectedChapter.hindiName}`,
                  chapterTitleOriginal: selectedChapter.nameSanskrit,
                  reference: `Bhagavad Gita ${selectedChapter.number}:${v.verse}`,
                  originalText: v.sanskrit,
                  transliteration: v.transliteration,
                  englishText: v.english,
                  hindiText: v.hindi,
                  attributionOriginal: selectedChapter.attribution.sanskrit,
                  attributionEn: selectedChapter.attribution.english,
                  attributionHi: selectedChapter.attribution.hindi,
                };
                return (
                  <VerseCard
                    key={hv.id}
                    verse={hv}
                    lang={lang}
                    preferences={preferences}
                    isBookmarked={isBookmarked(hv.id)}
                    onToggleBookmark={onToggleBookmark}
                  />
                );
              })}
            </div>
          )}
        </section>
      )}

      {/* Chapter / Surah Index */}
      {!searchResults && !selectedSurah && !selectedChapter && (
        <section className="space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <h2 className="font-display text-2xl text-[#F3F0E8]">
              {activeScripture === 'quran' ? t.common.quran : t.common.gita}
            </h2>
            <input
              type="text"
              value={chapterFilter}
              onChange={(e) => setChapterFilter(e.target.value)}
              placeholder={
                lang === 'hi' ? 'अध्याय या सूरह फ़िल्टर करें...' : 'Filter by number or name...'
              }
              className="sm:w-64 min-h-[44px] bg-[#15181C] border border-[#F3F0E8]/10 rounded-xl px-4 py-2 text-sm text-[#F3F0E8] placeholder:text-[#7D7970] focus:outline-none focus:border-[#C9A449]"
            />
          </div>

          {loadingIndex ? (
            <div className="bg-[#15181C] border border-[#F3F0E8]/10 rounded-2xl p-8 text-sm text-[#A6A197]">
              {t.common.loading}
            </div>
          ) : activeScripture === 'quran' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {filteredSurahs.map((s) => (
                <button
                  key={s.number}
                  type="button"
                  onClick={() => openSurah(s.number)}
                  className="text-left bg-[#15181C] border border-[#F3F0E8]/10 hover:border-[#C9A449]/45 rounded-2xl p-4 transition-colors flex items-center justify-between gap-4 cursor-pointer min-h-[76px]"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <span className="font-mono-num text-xs text-[#C9A449] w-8 h-8 rounded-lg bg-[#0D0E11] border border-[#F3F0E8]/10 flex items-center justify-center shrink-0">
                      {s.number}
                    </span>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-[#F3F0E8] truncate">
                        {s.englishName}
                      </p>
                      <p className="text-xs text-[#A6A197] truncate">
                        {s.englishNameTranslation} ·{' '}
                        <span className="font-mono-num">
                          {s.ayahCount} {t.common.ayahsCount}
                        </span>
                      </p>
                    </div>
                  </div>
                  <span className="font-arabic text-lg text-[#C9A449] shrink-0" lang="ar">
                    {s.nameArabic}
                  </span>
                </button>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {filteredChapters.map((c) => (
                <button
                  key={c.number}
                  type="button"
                  onClick={() => openGitaChapter(c.number)}
                  className="text-left bg-[#15181C] border border-[#F3F0E8]/10 hover:border-[#C9A449]/45 rounded-2xl p-5 transition-colors flex flex-col justify-between gap-3 cursor-pointer"
                >
                  <div className="flex items-start justify-between gap-3">
                    <span className="font-mono-num text-xs text-[#C9A449] px-2.5 py-1 rounded-lg bg-[#0D0E11] border border-[#F3F0E8]/10">
                      {t.common.chapter} {c.number}
                    </span>
                    <span className="font-mono-num text-xs text-[#A6A197]">
                      {c.verseCount} {t.common.versesCount}
                    </span>
                  </div>
                  <div>
                    <p className="text-base font-semibold text-[#F3F0E8]">
                      {lang === 'hi' ? c.hindiName : c.englishName}
                    </p>
                    <p className="font-devanagari text-xs text-[#C9A449] mt-0.5">
                      {c.nameSanskrit}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          )}
        </section>
      )}
    </div>
  );
};
