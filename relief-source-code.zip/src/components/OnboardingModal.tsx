import React, { useState } from 'react';
import { ArrowRight, Globe, ShieldCheck, Sparkles } from 'lucide-react';
import { AppLang } from '../types';
import { UI_COPY } from '../i18n/translations';

interface OnboardingModalProps {
  isOpen: boolean;
  lang: AppLang;
  onChangeLang: (lang: AppLang) => void;
  onComplete: () => void;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  isOpen,
  lang,
  onChangeLang,
  onComplete,
}) => {
  const [step, setStep] = useState(0);
  if (!isOpen) return null;

  const t = UI_COPY[lang];
  const slides = t.onboarding.slides;
  const current = slides[step];
  const isLast = step === slides.length - 1;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="onboarding-title"
    >
      <div className="w-full max-w-xl bg-[#15181C] border border-[#F3F0E8]/12 rounded-3xl p-6 md:p-8 shadow-2xl">
        <div className="flex items-center justify-between gap-4 pb-6 border-b border-[#F3F0E8]/8">
          <div className="flex items-center gap-2 text-xs text-[#C9A449]">
            <span className="font-display text-lg font-semibold tracking-wider text-[#F3F0E8]">
              RELIEF
            </span>
            <span aria-hidden="true">·</span>
            <span className="font-mono-num">
              0{step + 1} / 0{slides.length}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center bg-[#0D0E11] border border-[#F3F0E8]/10 rounded-xl p-1">
              <button
                type="button"
                onClick={() => onChangeLang('en')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  lang === 'en'
                    ? 'bg-[#C9A449] text-[#0D0E11]'
                    : 'text-[#A6A197] hover:text-[#F3F0E8]'
                }`}
              >
                English
              </button>
              <button
                type="button"
                onClick={() => onChangeLang('hi')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  lang === 'hi'
                    ? 'bg-[#C9A449] text-[#0D0E11]'
                    : 'text-[#A6A197] hover:text-[#F3F0E8]'
                }`}
              >
                हिन्दी
              </button>
            </div>

            <button
              type="button"
              onClick={onComplete}
              className="min-h-[40px] px-3 text-xs font-medium text-[#A6A197] hover:text-[#F3F0E8] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {t.onboarding.skip}
            </button>
          </div>
        </div>

        <div className="py-8 space-y-5">
          <div className="w-12 h-12 rounded-2xl bg-[#C9A449]/12 border border-[#C9A449]/30 flex items-center justify-center text-[#C9A449]">
            {step === 0 && <Globe className="w-5 h-5" />}
            {step === 1 && <ShieldCheck className="w-5 h-5" />}
            {step === 2 && <Sparkles className="w-5 h-5" />}
          </div>

          <h2
            id="onboarding-title"
            className="font-display text-3xl md:text-4xl font-medium text-[#F3F0E8] leading-tight text-balance"
          >
            {current.title}
          </h2>

          <p className="text-base text-[#A6A197] leading-relaxed">
            {current.body}
          </p>
        </div>

        <div className="flex items-center justify-between pt-6 border-t border-[#F3F0E8]/8">
          <div className="flex items-center gap-2">
            {slides.map((_, idx) => (
              <button
                key={idx}
                type="button"
                aria-label={`Slide ${idx + 1}`}
                onClick={() => setStep(idx)}
                className={`h-1.5 rounded-full transition-all cursor-pointer ${
                  idx === step ? 'w-8 bg-[#C9A449]' : 'w-2.5 bg-[#2A2E37]'
                }`}
              />
            ))}
          </div>

          <button
            type="button"
            onClick={() => {
              if (isLast) onComplete();
              else setStep((s) => s + 1);
            }}
            className="min-h-[44px] px-6 py-2.5 rounded-xl bg-[#C9A449] text-[#0D0E11] text-sm font-semibold inline-flex items-center gap-2 hover:bg-[#D8B55B] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <span>{isLast ? t.onboarding.start : t.onboarding.next}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
