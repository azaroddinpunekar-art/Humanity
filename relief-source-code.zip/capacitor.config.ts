import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'org.reliefwisdom.app',
  appName: 'RELIEF',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    cleartext: false,
  },
  android: {
    backgroundColor: '#0D0E11',
    allowMixedContent: false,
  },
};

export default config;
