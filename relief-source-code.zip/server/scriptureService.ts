import fs from 'fs';
import path from 'path';

export interface QuranAyah {
  numberInSurah: number;
  arabic: string;
  english: string;
  hindi: string;
}

export interface QuranSurah {
  number: number;
  nameArabic: string;
  englishName: string;
  englishNameTranslation: string;
  revelationType: string;
  ayahs: QuranAyah[];
}

export interface QuranDataset {
  attribution: {
    arabic: string;
    english: string;
    hindi: string;
  };
  surahs: QuranSurah[];
}

export interface GitaVerse {
  verse: number;
  sanskrit: string;
  transliteration: string;
  english: string;
  hindi: string;
}

export interface GitaChapter {
  number: number;
  nameSanskrit: string;
  transliteration: string;
  englishName: string;
  hindiName: string;
  summaryEn: string;
  summaryHi: string;
  verses: GitaVerse[];
}

export interface GitaDataset {
  attribution: {
    sanskrit: string;
    english: string;
    hindi: string;
  };
  chapters: GitaChapter[];
}

export interface HydratedVerse {
  id: string;
  scripture: 'quran' | 'gita';
  chapterNumber: number;
  verseNumber: number;
  chapterTitleEn: string;
  chapterTitleHi: string;
  chapterTitleOriginal: string;
  reference: string;
  originalText: string;
  transliteration?: string;
  englishText: string;
  hindiText: string;
  attributionOriginal: string;
  attributionEn: string;
  attributionHi: string;
}

const dataDir = path.resolve(process.cwd(), 'server', 'data');
const quranRaw: QuranDataset = JSON.parse(
  fs.readFileSync(path.join(dataDir, 'quran.json'), 'utf-8')
);
const gitaRaw: GitaDataset = JSON.parse(
  fs.readFileSync(path.join(dataDir, 'gita.json'), 'utf-8')
);

const SYNONYM_MAP: Record<string, string[]> = {
  anger: ['anger', 'angry', 'wrath', 'rage', 'temper', 'restrain', 'forbear', 'क्रोध', 'गुस्सा', 'क्षमा'],
  jealousy: ['jealous', 'envy', 'covet', 'resent', 'compare', 'desire', 'content', 'ईर्ष्या', 'जलन', 'द्वेष'],
  envy: ['envy', 'jealous', 'covet', 'greed', 'hatred', 'ईर्ष्या', 'द्वेष'],
  betrayal: ['betray', 'trust', 'treachery', 'deceit', 'pardon', 'forgive', 'patience', 'धोखा', 'विश्वासघात', 'क्षमा'],
  failure: ['fail', 'failure', 'loss', 'defeat', 'effort', 'action', 'hardship', 'ease', 'विफलता', 'असफल', 'हार', 'प्रयास'],
  money: ['wealth', 'money', 'greed', 'charity', 'spend', 'poor', 'rich', 'excess', 'धन', 'पैसा', 'लोभ', 'दान'],
  wealth: ['wealth', 'money', 'greed', 'charity', 'spend', 'property', 'धन', 'संपत्ति'],
  parents: ['parents', 'mother', 'father', 'kindness', 'elder', 'respect', 'माता', 'पिता', 'माता-पिता'],
  fear: ['fear', 'anxiety', 'worry', 'grief', 'sorrow', 'peace', 'calm', 'heart', 'भय', 'डर', 'चिंता', 'शांति'],
  anxiety: ['anxiety', 'fear', 'worry', 'grief', 'restless', 'mind', 'peace', 'चिंता', 'अशांति', 'मन'],
  loneliness: ['alone', 'lonely', 'friend', 'companionship', 'heart', 'near', 'अकेला', 'अकेलापन', 'साथ'],
  forgiveness: ['forgive', 'pardon', 'mercy', 'reconcile', 'excuse', 'क्षमा', 'माफ', 'दया'],
  truth: ['truth', 'honest', 'lie', 'falsehood', 'witness', 'sincere', 'सत्य', 'सच', 'ईमानदारी'],
  justice: ['justice', 'fair', 'equity', 'oppression', 'witness', 'न्याय', 'निष्पक्ष'],
  compassion: ['compassion', 'mercy', 'kind', 'gentle', 'love', 'creature', 'करुणा', 'दया', 'प्रेम'],
  greed: ['greed', 'desire', 'lust', 'attachment', 'covet', 'accumulate', 'लोभ', 'लालच', 'आसक्ति'],
  duty: ['duty', 'work', 'action', 'responsibility', 'service', 'karma', 'कर्तव्य', 'कर्म', 'उत्तरदायित्व'],
  humility: ['humble', 'humility', 'pride', 'arrogant', 'modest', 'boast', 'विनम्रता', 'अहंकार', 'घमंड'],
  patience: ['patience', 'patient', 'steadfast', 'persevere', 'endure', 'धैर्य', 'सहनशीलता', 'शांति'],
  peace: ['peace', 'calm', 'tranquil', 'serenity', 'steady', 'शांति', 'स्थिर'],
  purpose: ['purpose', 'meaning', 'create', 'life', 'soul', 'path', 'उद्देश्य', 'जीवन'],
  better: ['righteous', 'good', 'virtue', 'character', 'humble', 'kind', 'श्रेष्ठ', 'चरित्र', 'अच्छा'],
};

const STOP_WORDS = new Set([
  'the', 'is', 'a', 'an', 'of', 'to', 'in', 'and', 'or', 'for', 'with', 'on', 'at', 'by',
  'how', 'what', 'why', 'when', 'who', 'should', 'do', 'i', 'my', 'me', 'someone', 'when',
  'can', 'become', 'deal', 'handle', 'way', 'about', 'from', 'that', 'this', 'are', 'be',
  'क्या', 'कैसे', 'क्यों', 'मैं', 'मुझे', 'मेरा', 'है', 'हैं', 'को', 'में', 'से', 'का', 'की', 'के', 'और', 'या',
]);

export function getAttributions() {
  return {
    quran: quranRaw.attribution,
    gita: gitaRaw.attribution,
  };
}

export function getQuranSurahSummaries() {
  return quranRaw.surahs.map((s) => ({
    number: s.number,
    nameArabic: s.nameArabic,
    englishName: s.englishName,
    englishNameTranslation: s.englishNameTranslation,
    revelationType: s.revelationType,
    ayahCount: s.ayahs.length,
  }));
}

export function getQuranSurah(surahNumber: number) {
  const s = quranRaw.surahs.find((x) => x.number === surahNumber);
  if (!s) return null;
  return {
    ...s,
    attribution: quranRaw.attribution,
  };
}

export function getGitaChapterSummaries() {
  return gitaRaw.chapters.map((c) => ({
    number: c.number,
    nameSanskrit: c.nameSanskrit,
    transliteration: c.transliteration,
    englishName: c.englishName,
    hindiName: c.hindiName,
    summaryEn: c.summaryEn,
    summaryHi: c.summaryHi,
    verseCount: c.verses.length,
  }));
}

export function getGitaChapter(chapterNumber: number) {
  const c = gitaRaw.chapters.find((x) => x.number === chapterNumber);
  if (!c) return null;
  return {
    ...c,
    attribution: gitaRaw.attribution,
  };
}

export function hydrateQuranVerse(surahNumber: number, ayahNumber: number): HydratedVerse | null {
  const s = quranRaw.surahs.find((x) => x.number === surahNumber);
  if (!s) return null;
  const a = s.ayahs.find((x) => x.numberInSurah === ayahNumber);
  if (!a) return null;
  return {
    id: `quran:${s.number}:${a.numberInSurah}`,
    scripture: 'quran',
    chapterNumber: s.number,
    verseNumber: a.numberInSurah,
    chapterTitleEn: `${s.englishName} (${s.englishNameTranslation})`,
    chapterTitleHi: `${s.englishName} (${s.number})`,
    chapterTitleOriginal: s.nameArabic,
    reference: `Quran ${s.number}:${a.numberInSurah}`,
    originalText: a.arabic,
    englishText: a.english,
    hindiText: a.hindi,
    attributionOriginal: quranRaw.attribution.arabic,
    attributionEn: quranRaw.attribution.english,
    attributionHi: quranRaw.attribution.hindi,
  };
}

export function hydrateGitaVerse(chapterNumber: number, verseNumber: number): HydratedVerse | null {
  const c = gitaRaw.chapters.find((x) => x.number === chapterNumber);
  if (!c) return null;
  const v = c.verses.find((x) => x.verse === verseNumber);
  if (!v) return null;
  return {
    id: `gita:${c.number}:${v.verse}`,
    scripture: 'gita',
    chapterNumber: c.number,
    verseNumber: v.verse,
    chapterTitleEn: `Chapter ${c.number}: ${c.englishName}`,
    chapterTitleHi: `अध्याय ${c.number}: ${c.hindiName}`,
    chapterTitleOriginal: c.nameSanskrit,
    reference: `Bhagavad Gita ${c.number}:${v.verse}`,
    originalText: v.sanskrit,
    transliteration: v.transliteration,
    englishText: v.english,
    hindiText: v.hindi,
    attributionOriginal: gitaRaw.attribution.sanskrit,
    attributionEn: gitaRaw.attribution.english,
    attributionHi: gitaRaw.attribution.hindi,
  };
}

function expandSearchTerms(query: string, extraKeywords: string[] = []): string[] {
  const rawTokens = query
    .toLowerCase()
    .replace(/[?!.,;:"'()\[\]{}।]/g, ' ')
    .split(/\s+/)
    .filter((t) => t.length >= 2 && !STOP_WORDS.has(t));

  const expanded = new Set<string>([...rawTokens, ...extraKeywords.map((k) => k.toLowerCase())]);
  for (const tok of [...expanded]) {
    for (const [key, syns] of Object.entries(SYNONYM_MAP)) {
      if (tok.includes(key) || key.includes(tok) || syns.some((s) => s === tok)) {
        syns.forEach((s) => expanded.add(s));
      }
    }
  }
  return Array.from(expanded).filter((t) => t.length >= 2);
}

export function searchScriptures(
  query: string,
  options: {
    scripture?: 'all' | 'quran' | 'gita';
    limitPerScripture?: number;
    extraKeywords?: string[];
  } = {}
): { quran: HydratedVerse[]; gita: HydratedVerse[] } {
  const scripture = options.scripture ?? 'all';
  const limit = options.limitPerScripture ?? 12;

  // Check exact reference match e.g. "2:47" or "16:90"
  const refMatch = query.trim().match(/^(\d{1,3})\s*[:.]\s*(\d{1,3})$/);
  if (refMatch) {
    const ch = Number(refMatch[1]);
    const vs = Number(refMatch[2]);
    const qHit = scripture !== 'gita' ? hydrateQuranVerse(ch, vs) : null;
    const gHit = scripture !== 'quran' ? hydrateGitaVerse(ch, vs) : null;
    return {
      quran: qHit ? [qHit] : [],
      gita: gHit ? [gHit] : [],
    };
  }

  const terms = expandSearchTerms(query, options.extraKeywords);
  if (terms.length === 0) {
    return { quran: [], gita: [] };
  }

  const quranScored: Array<{ score: number; verse: HydratedVerse }> = [];
  if (scripture === 'all' || scripture === 'quran') {
    for (const s of quranRaw.surahs) {
      for (const a of s.ayahs) {
        const hay = `${a.english} ${a.hindi}`.toLowerCase();
        let score = 0;
        for (const term of terms) {
          if (hay.includes(term)) {
            score += term.length > 4 ? 3 : 2;
          }
        }
        // Slight boost for concise, clear ethical verses
        if (score > 0) {
          if (a.english.length >= 40 && a.english.length <= 360) score += 0.5;
          const hydrated = hydrateQuranVerse(s.number, a.numberInSurah);
          if (hydrated) quranScored.push({ score, verse: hydrated });
        }
      }
    }
  }

  const gitaScored: Array<{ score: number; verse: HydratedVerse }> = [];
  if (scripture === 'all' || scripture === 'gita') {
    for (const c of gitaRaw.chapters) {
      for (const v of c.verses) {
        const hay = `${v.english} ${v.hindi} ${v.transliteration}`.toLowerCase();
        let score = 0;
        for (const term of terms) {
          if (hay.includes(term)) {
            score += term.length > 4 ? 3 : 2;
          }
        }
        if (score > 0) {
          if (v.english.length >= 40 && v.english.length <= 360) score += 0.5;
          const hydrated = hydrateGitaVerse(c.number, v.verse);
          if (hydrated) gitaScored.push({ score, verse: hydrated });
        }
      }
    }
  }

  quranScored.sort((a, b) => b.score - a.score);
  gitaScored.sort((a, b) => b.score - a.score);

  return {
    quran: quranScored.slice(0, limit).map((x) => x.verse),
    gita: gitaScored.slice(0, limit).map((x) => x.verse),
  };
}
