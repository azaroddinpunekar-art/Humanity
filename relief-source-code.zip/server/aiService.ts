import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import {
  hydrateGitaVerse,
  hydrateQuranVerse,
  HydratedVerse,
  searchScriptures,
} from './scriptureService.ts';

export interface ChatHistoryTurn {
  role: 'user' | 'assistant';
  question?: string;
  summary?: string;
}

export interface AskReliefResult {
  detectedLanguage: 'en' | 'hi';
  situationSummary: string;
  quranVerses: Array<HydratedVerse & { relevanceNote: string }>;
  gitaVerses: Array<HydratedVerse & { relevanceNote: string }>;
  quranExplanation: string;
  gitaExplanation: string;
  sharedWisdom: string;
  philosophicalDifferences: string;
  practicalSteps: string[];
  professionalGuidanceNote: string;
  disclaimer: string;
}

function getAiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    const err = new Error('GEMINI_API_KEY is not configured on the server.');
    (err as Error & { statusCode?: number }).statusCode = 503;
    throw err;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function withRetry<T>(fn: () => Promise<T>, maxAttempts = 3): Promise<T> {
  let lastErr: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (err) {
      lastErr = err;
      const msg = err instanceof Error ? err.message : String(err);
      const isTransient =
        msg.includes('503') ||
        msg.includes('UNAVAILABLE') ||
        msg.includes('high demand') ||
        msg.includes('429');
      if (!isTransient || attempt === maxAttempts) {
        throw err;
      }
      await new Promise((r) => setTimeout(r, 800 * attempt));
    }
  }
  throw lastErr;
}

async function extractSearchKeywords(
  ai: GoogleGenAI,
  question: string,
  history: ChatHistoryTurn[]
): Promise<{ keywords: string[]; detectedLanguage: 'en' | 'hi' }> {
  const recentContext = history
    .slice(-4)
    .map((h) => (h.role === 'user' ? `User: ${h.question}` : `Context: ${h.summary}`))
    .join('\n');

  const response = await withRetry(() =>
    ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Analyze this user question (and optional recent context) and output 6 to 10 single-word English and Hindi ethical/emotional keywords to search scripture translations (The Quran and The Bhagavad Gita). Also detect whether the question is primarily in Hindi ('hi') or English ('en').

Recent Context:
${recentContext || 'None'}

Current Question:
${question}`,
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            detectedLanguage: {
              type: Type.STRING,
              description: "Either 'en' or 'hi'",
            },
            keywords: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '6-10 single words in English and Hindi relevant to the life situation',
            },
          },
          required: ['detectedLanguage', 'keywords'],
        },
      },
    })
  );

  const parsed = JSON.parse((response.text ?? '{}').trim()) as {
    detectedLanguage?: string;
    keywords?: string[];
  };
  return {
    detectedLanguage: parsed.detectedLanguage === 'hi' ? 'hi' : 'en',
    keywords: Array.isArray(parsed.keywords) ? parsed.keywords : [],
  };
}

export async function askRelief(
  question: string,
  preferredLanguage: 'en' | 'hi',
  history: ChatHistoryTurn[] = []
): Promise<AskReliefResult> {
  const ai = getAiClient();

  // Stage 1: Semantic keyword expansion + verified scripture retrieval
  let keywords: string[] = [];
  let detectedLanguage: 'en' | 'hi' = /[\u0900-\u097F]/.test(question) ? 'hi' : 'en';
  try {
    const extracted = await extractSearchKeywords(ai, question, history);
    keywords = extracted.keywords;
    detectedLanguage = extracted.detectedLanguage;
  } catch {
    // Fall back to deterministic local bilingual synonym retrieval if expansion temporarily spikes
  }
  const answerLang: 'en' | 'hi' =
    /[\u0900-\u097F]/.test(question) || detectedLanguage === 'hi'
      ? 'hi'
      : preferredLanguage;

  const retrieved = searchScriptures(question, {
    extraKeywords: keywords,
    limitPerScripture: 6,
  });

  const quranCandidatesText =
    retrieved.quran.length > 0
      ? retrieved.quran
          .map(
            (v) =>
              `[Surah ${v.chapterNumber}:${v.verseNumber} (${v.chapterTitleEn})] English: "${v.englishText}" | Hindi: "${v.hindiText}"`
          )
          .join('\n')
      : 'NO_DIRECT_QURAN_CANDIDATE_FOUND';

  const gitaCandidatesText =
    retrieved.gita.length > 0
      ? retrieved.gita
          .map(
            (v) =>
              `[Chapter ${v.chapterNumber}:${v.verseNumber} (${v.chapterTitleEn})] English: "${v.englishText}" | Hindi: "${v.hindiText}"`
          )
          .join('\n')
      : 'NO_DIRECT_GITA_CANDIDATE_FOUND';

  const conversationMemory = history
    .slice(-6)
    .map((h) =>
      h.role === 'user'
        ? `User asked: ${h.question}`
        : `RELIEF reflected: ${h.summary}`
    )
    .join('\n');

  const systemInstruction = `You are RELIEF, a secular, inclusive, compassionate wisdom and scripture reflection companion grounded in Two Scriptures: The Holy Quran and The Bhagavad Gita.
Core Philosophy: "Two Scriptures. Shared Wisdom. One Humanity."

CRITICAL RULES:
1. NEVER claim one scripture is superior, never preach conversion, never ridicule any belief or non-belief.
2. NEVER invent, alter, or guess any Surah:Ayah, Chapter:Verse, Arabic, Sanskrit, or translation. You may ONLY select verse references that appear verbatim in the RETRIEVED CANDIDATES provided below.
3. If NO candidate in one scripture directly addresses the user's question, return an empty array for that scripture's selected refs and honestly state in that tradition's explanation that no directly matching passage was retrieved for this specific query—never fabricate a connection.
4. NEVER force both scriptures to say the exact same thing. Identify genuine shared ethical principles ONLY where truly supported, and honestly explain meaningful philosophical or contextual differences.
5. Clearly separate reflection from religious authority: state clearly in the disclaimer that RELIEF offers educational and reflective perspective, not an authoritative religious ruling (fatwa/shastra decree).
6. If the user's situation touches medical illness, severe mental distress/self-harm, domestic abuse, legal disputes, or acute financial/emergency crisis, you MUST populate 'professionalGuidanceNote' clearly advising qualified professional, medical, legal, or emergency support. Otherwise set 'professionalGuidanceNote' to an empty string "".
7. Respond ENTIRELY in ${answerLang === 'hi' ? 'Hindi (Devanagari, clear and warm natural Hindi)' : 'English (clear, warm, dignified prose)'}.`;

  const prompt = `Conversation History:
${conversationMemory || 'None (first question)'}

User's Question:
"${question}"

RETRIEVED VERIFIED QURAN CANDIDATES:
${quranCandidatesText}

RETRIEVED VERIFIED BHAGAVAD GITA CANDIDATES:
${gitaCandidatesText}

Select up to 2 most relevant verified Quran references (only from the candidates above) and up to 2 most relevant verified Gita references (only from the candidates above). Explain each tradition independently, identify genuine shared ethical wisdom if supported, note real philosophical differences, and offer 3-5 balanced everyday steps.`;

  const response = await withRetry(() =>
    ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: prompt,
      config: {
        systemInstruction,
        thinkingConfig: { thinkingLevel: ThinkingLevel.MEDIUM },
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            situationSummary: {
              type: Type.STRING,
              description: 'Empathetic 2-sentence summary of the user situation and core emotional/ethical question.',
            },
            selectedQuranRefs: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  surah: { type: Type.INTEGER },
                  ayah: { type: Type.INTEGER },
                  relevanceNote: { type: Type.STRING },
                },
                required: ['surah', 'ayah', 'relevanceNote'],
              },
            },
            selectedGitaRefs: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  chapter: { type: Type.INTEGER },
                  verse: { type: Type.INTEGER },
                  relevanceNote: { type: Type.STRING },
                },
                required: ['chapter', 'verse', 'relevanceNote'],
              },
            },
            quranExplanation: {
              type: Type.STRING,
              description: 'Independent, respectful explanation of the Quranic perspective based on retrieved verses.',
            },
            gitaExplanation: {
              type: Type.STRING,
              description: 'Independent, respectful explanation of the Bhagavad Gita perspective based on retrieved verses.',
            },
            sharedWisdom: {
              type: Type.STRING,
              description: 'Genuine shared ethical principle if supported by the texts, or honest note if approached differently.',
            },
            philosophicalDifferences: {
              type: Type.STRING,
              description: 'Honest explanation of distinct philosophical framing, context, or metaphysical perspective between the two texts.',
            },
            practicalSteps: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '3 to 5 practical, everyday human steps.',
            },
            professionalGuidanceNote: {
              type: Type.STRING,
              description: 'Non-empty guidance encouraging medical, mental health, legal, financial, or emergency professionals when relevant; otherwise empty string.',
            },
            disclaimer: {
              type: Type.STRING,
              description: 'Clear educational reflection disclaimer (not a religious ruling).',
            },
          },
          required: [
            'situationSummary',
            'selectedQuranRefs',
            'selectedGitaRefs',
            'quranExplanation',
            'gitaExplanation',
            'sharedWisdom',
            'philosophicalDifferences',
            'practicalSteps',
            'professionalGuidanceNote',
            'disclaimer',
          ],
        },
      },
    })
  );

  const raw = JSON.parse((response.text ?? '{}').trim()) as {
    situationSummary?: string;
    selectedQuranRefs?: Array<{ surah: number; ayah: number; relevanceNote: string }>;
    selectedGitaRefs?: Array<{ chapter: number; verse: number; relevanceNote: string }>;
    quranExplanation?: string;
    gitaExplanation?: string;
    sharedWisdom?: string;
    philosophicalDifferences?: string;
    practicalSteps?: string[];
    professionalGuidanceNote?: string;
    disclaimer?: string;
  };

  // Strictly validate and hydrate references directly from the verified archive!
  const allowedQuranIds = new Set(retrieved.quran.map((v) => v.id));
  const allowedGitaIds = new Set(retrieved.gita.map((v) => v.id));

  const verifiedQuranVerses: Array<HydratedVerse & { relevanceNote: string }> = [];
  for (const ref of raw.selectedQuranRefs ?? []) {
    const id = `quran:${ref.surah}:${ref.ayah}`;
    if (!allowedQuranIds.has(id)) continue;
    const hydrated = hydrateQuranVerse(ref.surah, ref.ayah);
    if (hydrated && !verifiedQuranVerses.some((v) => v.id === hydrated.id)) {
      verifiedQuranVerses.push({
        ...hydrated,
        relevanceNote: ref.relevanceNote || '',
      });
    }
  }

  const verifiedGitaVerses: Array<HydratedVerse & { relevanceNote: string }> = [];
  for (const ref of raw.selectedGitaRefs ?? []) {
    const id = `gita:${ref.chapter}:${ref.verse}`;
    if (!allowedGitaIds.has(id)) continue;
    const hydrated = hydrateGitaVerse(ref.chapter, ref.verse);
    if (hydrated && !verifiedGitaVerses.some((v) => v.id === hydrated.id)) {
      verifiedGitaVerses.push({
        ...hydrated,
        relevanceNote: ref.relevanceNote || '',
      });
    }
  }

  return {
    detectedLanguage: answerLang,
    situationSummary: raw.situationSummary || '',
    quranVerses: verifiedQuranVerses,
    gitaVerses: verifiedGitaVerses,
    quranExplanation: raw.quranExplanation || '',
    gitaExplanation: raw.gitaExplanation || '',
    sharedWisdom: raw.sharedWisdom || '',
    philosophicalDifferences: raw.philosophicalDifferences || '',
    practicalSteps: Array.isArray(raw.practicalSteps) ? raw.practicalSteps : [],
    professionalGuidanceNote: raw.professionalGuidanceNote || '',
    disclaimer:
      raw.disclaimer ||
      (answerLang === 'hi'
        ? 'यह उत्तर शैक्षिक और चिंतनशील मार्गदर्शन के लिए AI द्वारा तैयार किया गया है, इसे कोई धार्मिक फतवा या आधिकारिक शास्त्रीय निर्णय न मानें।'
        : 'This reflection is generated by AI for educational contemplation and is not an authoritative religious ruling.'),
  };
}
