import express from 'express';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import JSZip from 'jszip';
import { createServer as createViteServer } from 'vite';
import {
  getAttributions,
  getGitaChapter,
  getGitaChapterSummaries,
  getQuranSurah,
  getQuranSurahSummaries,
  searchScriptures,
} from './server/scriptureService.ts';
import {
  getDailyWisdom,
  getOneHumanityTopics,
  getSituationCategories,
} from './server/curatedData.ts';
import { askRelief, ChatHistoryTurn } from './server/aiService.ts';

dotenv.config();

const PORT = 3000;
const app = express();
app.use(express.json({ limit: '1mb' }));

// Health & metadata
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', version: '1.0.0' });
});

app.get('/api/attributions', (_req, res) => {
  res.json(getAttributions());
});

app.get('/api/daily-wisdom', (req, res) => {
  const dateStr = typeof req.query.date === 'string' ? req.query.date : undefined;
  res.json(getDailyWisdom(dateStr));
});

// Complete Quran API
app.get('/api/quran/surahs', (_req, res) => {
  res.json({ surahs: getQuranSurahSummaries() });
});

app.get('/api/quran/surah/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1 || id > 114) {
    return res.status(400).json({ error: 'Invalid Surah number (1-114).' });
  }
  const surah = getQuranSurah(id);
  if (!surah) {
    return res.status(404).json({ error: 'Surah not found.' });
  }
  return res.json(surah);
});

// Complete Bhagavad Gita API
app.get('/api/gita/chapters', (_req, res) => {
  res.json({ chapters: getGitaChapterSummaries() });
});

app.get('/api/gita/chapter/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1 || id > 18) {
    return res.status(400).json({ error: 'Invalid Chapter number (1-18).' });
  }
  const chapter = getGitaChapter(id);
  if (!chapter) {
    return res.status(404).json({ error: 'Chapter not found.' });
  }
  return res.json(chapter);
});

// Full-text retrieval search across both complete scriptures
app.get('/api/search', (req, res) => {
  const q = typeof req.query.q === 'string' ? req.query.q.trim() : '';
  const scripture =
    req.query.scripture === 'quran' || req.query.scripture === 'gita'
      ? req.query.scripture
      : 'all';
  if (!q) {
    return res.json({ quran: [], gita: [] });
  }
  const results = searchScriptures(q, { scripture, limitPerScripture: 20 });
  return res.json(results);
});

// One Humanity (15 values)
app.get('/api/one-humanity', (_req, res) => {
  res.json({ topics: getOneHumanityTopics() });
});

// Situation Explorer (11 categories)
app.get('/api/situations', (_req, res) => {
  res.json({ categories: getSituationCategories() });
});

// Ask RELIEF (Grounded Gemini AI)
app.post('/api/ask-relief', async (req, res) => {
  try {
    const body = req.body as {
      question?: string;
      language?: 'en' | 'hi';
      history?: ChatHistoryTurn[];
    };
    const question = (body.question || '').trim();
    if (!question || question.length < 3) {
      return res.status(400).json({ error: 'Please enter a meaningful question.' });
    }
    if (question.length > 1500) {
      return res.status(400).json({ error: 'Question must be under 1500 characters.' });
    }
    const language = body.language === 'hi' ? 'hi' : 'en';
    const history = Array.isArray(body.history) ? body.history : [];
    const result = await askRelief(question, language, history);
    return res.json(result);
  } catch (err) {
    const error = err as Error & { statusCode?: number; status?: number };
    const status = error.statusCode || error.status || 500;
    console.error('Ask RELIEF error:', error);
    let cleanMessage = error.message || 'Unable to generate wisdom reflection right now.';
    try {
      const parsed = JSON.parse(cleanMessage) as { error?: { message?: string; code?: number } };
      if (parsed?.error?.message) {
        cleanMessage = parsed.error.message;
      }
    } catch {
      // Keep original string if not JSON
    }
    if (status === 429) {
      return res.status(429).json({
        error: 'Rate limit reached on the AI wisdom service. Please pause a moment and try again.',
      });
    }
    return res.status(status >= 400 && status < 600 ? status : 500).json({
      error: cleanMessage,
    });
  }
});

// Feedback persistence (JSON lines file on server)
app.post('/api/feedback', (req, res) => {
  const { category, message, email } = req.body as {
    category?: string;
    message?: string;
    email?: string;
  };
  if (!message || !message.trim()) {
    return res.status(400).json({ error: 'Feedback message is required.' });
  }
  const feedbackPath = path.resolve(process.cwd(), 'server', 'data', 'feedback.jsonl');
  const record = {
    id: `fb_${Date.now()}`,
    createdAt: new Date().toISOString(),
    category: (category || 'general').slice(0, 60),
    message: message.trim().slice(0, 2000),
    email: (email || '').trim().slice(0, 120),
  };
  fs.appendFileSync(feedbackPath, JSON.stringify(record) + '\n', 'utf-8');
  return res.json({ ok: true, id: record.id });
});

// Download complete source code + Capacitor Android project as ZIP
app.get('/api/export-source', async (_req, res) => {
  try {
    const rootDir = process.cwd();
    const zip = new JSZip();

    const EXCLUDED_DIRS = new Set([
      'node_modules',
      'dist',
      '.git',
      '.gradle',
      'build',
      '.idea',
      '.cache',
    ]);
    const EXCLUDED_FILES = new Set([
      '.env',
      '.env.local',
      '.env.production',
      'feedback.jsonl',
    ]);

    const addDirectoryToZip = (currentDir: string, relBase: string) => {
      const entries = fs.readdirSync(currentDir, { withFileTypes: true });
      for (const entry of entries) {
        if (entry.isDirectory()) {
          if (EXCLUDED_DIRS.has(entry.name)) continue;
          const nextDir = path.join(currentDir, entry.name);
          const nextRel = relBase ? `${relBase}/${entry.name}` : entry.name;
          addDirectoryToZip(nextDir, nextRel);
        } else if (entry.isFile()) {
          if (EXCLUDED_FILES.has(entry.name)) continue;
          const fullPath = path.join(currentDir, entry.name);
          const zipPath = relBase ? `${relBase}/${entry.name}` : entry.name;
          const content = fs.readFileSync(fullPath);
          zip.file(zipPath, content);
        }
      }
    };

    addDirectoryToZip(rootDir, '');

    const zipBuffer = await zip.generateAsync({
      type: 'nodebuffer',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 },
    });

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader(
      'Content-Disposition',
      'attachment; filename="relief-source-code.zip"'
    );
    res.setHeader('Content-Length', String(zipBuffer.length));
    return res.send(zipBuffer);
  } catch (err) {
    console.error('Export ZIP error:', err);
    return res.status(500).json({ error: 'Failed to package source archive.' });
  }
});

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`RELIEF server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start RELIEF server:', err);
  process.exit(1);
});
